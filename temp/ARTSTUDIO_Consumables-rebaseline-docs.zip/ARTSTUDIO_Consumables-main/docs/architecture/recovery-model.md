# Карта восстановления и пересборки vNext

Связанные документы:

- Карта инвариантов: [./invariants.md](./invariants.md)
- Карта read-model: [./read-model-map.md](./read-model-map.md)
- Спецификация vNext: [../product/spec-vnext.md](../product/spec-vnext.md)

## 1. Термины восстановления

- **rollback** — регламентированный откат последствий конкретного действия или набора действий.
- **reset** — контролируемый сброс целевого состояния/представления с последующим восстановлением.
- **re-sync** — повторная синхронизация канонического и производных слоёв до согласованного состояния.

## 2. Различия между rollback, reset и re-sync

1. **rollback** применяется, когда нужно отменить влияние конкретной операции, сохранив трассируемость и аудит.
2. **reset** применяется, когда целевой слой (чаще проекционный или модульный) должен быть пересобран «с чистого состояния».
3. **re-sync** применяется, когда канон остаётся валидным, но производные/интеграционные слои нужно дотянуть до актуального состояния.

## 3. Три уровня применения

### 3.1 Локальное действие

- Пример: отмена/коррекция отдельного движения.
- Инструмент: rollback в рамках write-flow учётных событий.
- Цель: исправить локальную ошибку без разрушения глобального контура.

### 3.2 Модуль или слой

- Пример: сбой аналитической или рабочей проекции, частичное рассогласование импорта.
- Инструмент: reset/re-sync для конкретного модуля или класса проекций.
- Цель: восстановить целевой слой без полного системного воздействия.

### 3.3 Пространство в целом

- Пример: массовая критическая рассогласованность, подтверждённая диагностикой.
- Инструмент: управляемый план rollback/reset/re-sync через control plane и регламент инцидента.
- Цель: вернуть пространство к консистентному состоянию с полным аудитом.

## 4. Связь с историей, аудитом и инвариантами

1. Любой recovery-сценарий обязан оставлять аудитный след: кто, когда, зачем и что изменил.
2. Восстановление не может нарушать историческую трассируемость.
3. Recovery действует как механизм защиты инвариантов, а не как способ «обойти правила».
4. Приоритет: сначала сохранить каноническую целостность, затем восстановить проекции и UX-слой.

## 5. Связь с допустимым отсутствием неключевых аналитик

- Отсутствие неключевых аналитик не считается аварией само по себе.
- Recovery не должен принудительно включать отключённые аналитики, если конфигурация допустима.
- При reset/re-sync аналитических проекций система обязана корректно работать в минимальном обязательном составе слоёв.

## 6. Эксплуатационные правила

1. Запуск recovery выполняется через управляющие сценарии control plane.
2. Ручной SQL-ремонт производных таблиц вне регламента недопустим.
3. После recovery должны запускаться consistency checks и подтверждение работоспособности базовых проекций.


## 4. R3.2 foundation: recovery trace в write-result

Событийный use-case слой R3.2 возвращает `recovery` контекст в success-результате:

- `eventContextId` (канонический id события/транзакции);
- `causalChain` (минимальная цепочка причина-следствие);
- `correlationId` (сквозной контекст запроса).

Контракт не реализует rollback/reset/re-sync полностью, но фиксирует идентичность и трассировку события, требуемую для следующей волны recovery.


## 5. R3.3 foundation: read-side rebuild/validation contract

В `src/lib/read-models/projections/update-registry.ts` зафиксированы:
- `projection receipts` (последний обработанный transaction/event по виду проекции);
- `read model recovery contract` (какие виды проекций rebuildable/validateable).

Это не полный re-sync engine, но явная стартовая точка для R3.4/R8 consistency enforcement.

## 6. R3.4 implementation (touched area)

В R3.4 recovery-процедуры перестали быть только foundation-контрактом и получили кодовый execution-layer:

- `src/lib/application/recovery/contracts.ts` — structured contracts команд/результатов и consistency report.
- `src/lib/application/recovery/service.ts` — use-case реализация rollback/reset/re-sync/check.
- recovery use-cases доступны через internal service-level invocation (`createRecoveryService`).

Реализованное покрытие:

1. **rollback (локально):** movement `IN/OUT/ADJUST` через отмену (`CANCELLED`) и аудит без удаления истории;
2. **reset (модульно):** reset projection receipts/recovery state для выбранных проекций;
3. **re-sync (модульно):** rebuild markers/receipts по каноническому состоянию;
4. **consistency check:** детекция blocking mismatch + выделение допустимого reduced eligibility как неблокирующего состояния.

Ограничение текущего шага: rollback `OPENING` / `INVENTORY_APPLY` отложен на следующую recovery-волну без изменения канона R3.4.

## R4 update: recovery для import touched flow

Для Import v2 реализован вызываемый rollback-path на touched scope:

- удаление import-created opening transaction;
- удаление item, созданных импортом (если по ним нет новых движений);
- восстановление snapshot для item, обновлённых импортом;
- фиксация `rolledBackAt` в rollback metadata import job;
- обновление projection receipts после rollback.

Ограничение локализовано: это scoped rollback import consequences, а не universal rollback всех возможных последующих цепочек.

## R5.4 update: local rollback bridge в хабе «Движения»

На UI-уровне хаба «Движения» добавлен быстрый post-action bridge к recovery use-case:

- endpoint `POST /api/transactions/[id]/rollback` вызывает `rollbackMovement` из `src/lib/application/recovery/service.ts`;
- bridge используется только как локальная отмена **недавнего** действия из result layer;
- scope остаётся touched-safe: movement rollback (`IN/OUT/ADJUST`), без universal rollback UI;
- история и аудит сохраняются (канон R3.4), пользователь не переводится в «Историю» для immediate undo path.

Таким образом recovery foundation R3.4 начинает работать как часть повседневного рабочего цикла, а не только как эксплуатационный toolkit.
